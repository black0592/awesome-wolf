var isChecked = false;
function clickHandler() {
  isChecked = !isChecked;
  document.getElementById('label').className = isChecked ? 'checked' : 'unchecked';
}